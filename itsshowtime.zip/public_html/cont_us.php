<?php
session_start();
$cid=$_SESSION['c_id'];

include "connection.php";

$name=$_POST['name'];
$email=$_POST["email"];
$message=$_POST["message"];

// echo $name."<Br>".$email."<br>".$message;
$query="INSERT INTO `contact_us`(`cont_id`, `cont_name`, `cont_email`, `cont_mssg`, `cid`) VALUES (null,'$name','$email','$message','$cid')";
$cmd=mysqli_query($con,$query);
header("location:contact.html?sent");
?>