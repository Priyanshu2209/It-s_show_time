<?php
session_start();
$sid=$_SESSION['s_id'];
include "connection.php";
    // print_r($_POST['emp']);
   $arr=explode(",", $_GET['seat']);
    // print_r(gettype($_GET['seat']));
    
    $i=0;
    foreach($arr as $item)
    {
        $query="select *from `seat` where Seatid='$item'";
        $cmd=mysqli_query($con,$query);
       
        foreach($cmd as $val)
        {
            $seat_no[$i]=$val['Seatno'];
            // echo $seat_no[$i];
            // array_push($seat_no,$val['Seatno']);
        }
       
        $seat_ids[$i]=$item;
        // echo " ".$seat_ids[$i];
        $i++;
    }
    $_SESSION['seats']=$seat_no;
    $_SESSION['seat_ids']=$seat_ids;
?>

<html>

  <head>
    <title> Payment | Its Show Time</title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="css/bootstrap.min.css">
  <body>

<div class="container">
    <div class="row">
        <div class="jumbotron" > 
          <h1 class="text-center">Online Payment</h1>
          <p class="text-center">Enter your payment details below.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="credit-card-div">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <form action="seat_bill.php" method="post">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <h5 class="text-muted"> Credit Card Number</h5>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <input type="text" class="form-control" placeholder="0000" required>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <input type="text" class="form-control" placeholder="0000" required>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <input type="text" class="form-control" placeholder="0000" required>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <input type="text" class="form-control" placeholder="0000" required>
                            </div>
                        </div>
                        <br>
                        <div class="row ">
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <span class="help-block text-muted small-font"> Expiry Month</span>
                                <input type="text" class="form-control" placeholder="MM" required>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <span class="help-block text-muted small-font">  Expiry Year</span>
                                <input type="text" class="form-control" placeholder="YYYY" required>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-3">
                                <span class="help-block text-muted small-font">  CCV</span>
                                <input type="text" class="form-control" placeholder="CCV" required>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-3"><br>
                                <img src="Admin/images/Rupay.jpg" class="img-rounded" >
                            </div>
                        </div>
                        <br>
                        <div class="row ">
                            <div class="col-md-12 pad-adjust">

                                <input type="text" class="form-control" placeholder="Name On The Card" required>
                            </div>
                        </div>
                        <br>
                        <div class="row ">
                            <!-- <form action="show_seat.php?show=<?php echo $sid; ?>" method=""> -->
                            <div class="col-md-6 col-sm-6 col-xs-6 pad-adjust">
                             <!-- <a href="show_seat.php?show=<?php echo $sid; ?>" style="text-decoration: none;"> -->
                             <button type="submit" class="btn btn-danger btn-block"  onclick="payment_done()">CANCEL</button></a>   
                            </div>
                            <!-- </form> -->
                            <div class="col-md-6 col-sm-6 col-xs-6 pad-adjust">
                              <button type="submit" class="btn btn-success btn-block">PAY NOW</button>
                            <!-- </a>   -->
                            </div>
                        </div>
                        </form>     
                    </div>
                </div>
            </div>
          
        </div>
    </div>
</div>
<script>
    function payment_done()
    {
        // <a href="seat_bill.php" style="text-decoration: none;">
        var src="show_seat.php?show=<?php echo $sid; ?>";
        window.location.href=src;
    }
</script>
</body>
</html>

<?php

// $hey=$_SESSION['seat_ids'];

// foreach($hey as $val)
// {
//     echo $val;
    
// }
?>
