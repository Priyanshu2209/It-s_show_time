<html>
    <head>
        <title>Admin Panel</title>
        <link rel="stylesheet"  href="css/admin_option.css">
        <link rel="stylesheet" href="css/scroll_bar.css">
    </head>
<body>

<?php
// require('_header.php');
?>
   <?php
   session_start();
  require("../connection.php");
  if(isset($_SESSION['a_user']))
{   $admin=$_SESSION['a_user'];
      ?>
       <div class="hero">
           <div class="contain">
               <div class="home_back"><a href="home.php?admin=<?php echo $admin; ?>">&#8249; home</a></div>
           <div class="form-box">
            
           <h1> Welcome, <?php echo $_SESSION['a_user']; ?> !!</h1>
           <div class="input-group2">
                 <a href="add_admin.php" style="text-decoration:none;"> <button type="submit" name="jodd" class="submit-btn">Register Admin</button></a>
                 <a href="book_history.php" style="text-decoration:none;"> <button type="submit" name="book" class="submit-btn">Show Booking History</button></a>
                  <a href="logout.php" style="text-decoration:none;"> <button type="submit" name="book" class="submit-btn">Logout</button></a>
                </div>
           </div>
       </div>
       </div>
    <?php } 
    else{ ?>
        <link rel="stylesheet" href="admin.css">
        <div class="hero">
            <div class="contain">
            <div class="form-box">
            <div class="input-group2">
            
            <?php 
            echo "Please Log in";
            ?>
            </div>
            </div>
            </div>
            </div>
            
    <?php
    }
    ?>
    
</body>
</html>