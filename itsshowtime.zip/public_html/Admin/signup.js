var x= document.getElementById("Login").style.left="-450px"; 
var y= document.getElementById("Register").style.left="50px";         
var z= document.getElementById("btn").style.left="100px";
var es= document.getElementById("error_sign").style.left="50px";
var erl=document.getElementById("error_login_").style.left="-450px";
