<?php
    $host = "localhost";
    $user = "id18310367_projectdata";                     
    $pass = "Itssh@wtime22";                                  
    $db = "id18310367_project";
   
     $con = mysqli_connect($host, $user, $pass, $db);
    //  $con = mysqli_connect("localhost","id18310367_projectdata","Itssh@wtime22","id18310367_project");
?>